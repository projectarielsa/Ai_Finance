<?php

namespace Database\Factories;

use Illuminate\Database\Eloquent\Factories\Factory;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Str;

class UserFactory extends Factory
{
    protected static ?string $password;

    public function definition(): array
    {
        return [
            'name'                     => fake()->name(),
            'email'                    => fake()->unique()->safeEmail(),
            'email_verified_at'        => now(),
            'password'                 => static::$password ??= Hash::make('password'),
            'phone'                    => '62' . fake()->numerify('8##########'),
            'role'                     => 'user',
            'is_active'                => true,
            'whatsapp_notifications'   => true,
            'minimum_balance_warning'  => 100000,
            'remember_token'           => Str::random(10),
        ];
    }

    public function unverified(): static
    {
        return $this->state(fn (array $attributes) => ['email_verified_at' => null]);
    }

    public function admin(): static
    {
        return $this->state(fn (array $attributes) => ['role' => 'admin']);
    }
}
